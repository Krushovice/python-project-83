from page_analyzer import app

__all__ = ['app']
